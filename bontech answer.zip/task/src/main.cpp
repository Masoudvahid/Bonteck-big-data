#include "histogram.hpp"
#include "lazycsv.hpp"
#include <bytell_hash_map.hpp>
#include <chrono>
#include <flat_hash_map.hpp>
#include <iostream>
#include <unordered_map>
#include <vector>

template<typename F>
auto benchmark(F&& f)
{
    auto t1 = std::chrono::high_resolution_clock::now();
    f();
    auto t2 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1).count();
    std::cout << duration << '\n';
}

struct subscriber
{
    uint8_t queued{};
    histogram<uint16_t, 30> hist{};
    std::array<uint16_t, 30> maxs{};

    bool update(uint16_t value)
    {
        hist.emplace(value);
        queued++;
        if (queued == hist.size())
        {
            remax();
            return true;
        }
        return false;
    }

    void remax()
    {
        constexpr const size_t H = decltype(hist)::size();
        constexpr const size_t M = H;
        std::array<uint16_t, M + H> tmp;

        std::copy(maxs.begin(), maxs.end(), tmp.begin());
        std::copy(hist.begin(), hist.begin() + queued, tmp.begin() + M);

        std::partial_sort(tmp.begin(), tmp.begin() + M, tmp.begin() + M + queued, std::greater<>());
        std::copy(tmp.begin(), tmp.begin() + M, maxs.begin());
        queued = 0;
    }
};

// using map_t = std::unordered_map<uint32_t, subscriber>;
// using map_t = ska::flat_hash_map<uint32_t, subscriber>;
using map_t = ska::bytell_hash_map<uint32_t, subscriber>;

int main()
{
    map_t map;
    map.reserve(5'000'000);

    lazycsv::parser list("./ids.csv");

    benchmark(
        [&]
        {
            for (const auto& row : list)
            {
                auto [id] = row.cells(0);
                map.emplace(std::atoi(id.raw().cbegin()), subscriber{});
            }
        });

    for (int i = 0; i <= 1; i++)
    {
        lazycsv::parser input("./input" + std::to_string(i) + ".csv");
        benchmark(
            [&]
            {
                for (const auto& row : input)
                {
                    auto [id, duration] = row.cells(0, 1);
                    auto it = map.find(std::atoi(id.raw().cbegin()));
                    if (it != map.end())
                    {
                        auto& subscriber = it->second;
                        uint16_t dur = std::atoi(duration.raw().cbegin());
                        subscriber.update(dur);
                    }
                }
            });
    }

    for (auto& [_, m] : map)
        m.remax();

    std::vector<uint32_t> vec;
    vec.reserve(map.size());

    for (auto& [id, _] : map)
        vec.push_back(id);

    std::sort(vec.begin(), vec.end());
}